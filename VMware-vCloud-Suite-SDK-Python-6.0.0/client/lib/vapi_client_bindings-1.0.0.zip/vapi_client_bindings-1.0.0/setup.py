"""
Setup file for vapi client bindings
"""
__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2012-2014 VMware, Inc.  All rights reserved. -- VMware Confidential'

import os
try:
    from setuptools import setup, find_packages
except ImportError:
    from distribute_setup import use_setuptools
    use_setuptools()
    from setuptools import setup, find_packages
from com.vmware.vapi import __version__


setup(
    name = 'vapi_client_bindings',
    version = __version__,
    author = __author__,
    description = 'vapi client bindings for VMware vCloud Suite',
    packages = find_packages(),
    classifiers = [],
    install_requires = [
        'setuptools',
        'vapi_runtime>=1.0.0',
        'vapi_common_client>=1.0.0',
    ]
)
