"""
User password Security Helper
"""

__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2013 VMware, Inc.  All rights reserved. -- VMware Confidential'

from vmware.vapi.core import SecurityContext
from vmware.vapi.lib.constants import SCHEME_ID

USER_PASSWORD_SCHEME_ID = 'com.vmware.vapi.std.security.user_pass'
USER_KEY = 'userName'
PASSWORD_KEY = 'password'


def create_user_password_security_context(user_name, password):
    """
    Create a security context for Username-Password based authentication
    scheme

    :type  user_name: :class:`str`
    :param user_name: Name of the user
    :type  password: :class:`str`
    :param password: Password of the user
    :rtype: :class:`vmware.vapi.core.SecurityContext`
    :return: Newly created security context
    """
    return SecurityContext({SCHEME_ID: USER_PASSWORD_SCHEME_ID,
                            USER_KEY: user_name,
                            PASSWORD_KEY: password})
