"""
Session Security Helper
"""

__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2011 VMware, Inc.  All rights reserved. -- VMware Confidential'

from vmware.vapi.core import SecurityContext
from vmware.vapi.lib.constants import SCHEME_ID

SESSION_SCHEME_ID = 'com.vmware.vapi.std.security.session_id'
SESSION_ID = 'sessionId'


def create_session_security_context(session_id):
    """
    Create a security context for Session Id based authentication
    scheme

    :type  session_id: :class:`str`
    :param session_id: Session ID
    :rtype: :class:`vmware.vapi.core.SecurityContext`
    :return: Newly created security context
    """
    return SecurityContext({SCHEME_ID: SESSION_SCHEME_ID,
                            SESSION_ID: session_id})
