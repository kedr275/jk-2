"""
Helper classes for aggregator services
"""

__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2011-2012 VMware, Inc.  All rights reserved. -- VMware Confidential'

import logging
import time

logger = logging.getLogger(__name__)


class Stats(object):
    """
    Class that provides stats hooks to ApiAggregator
    """""

    def __init__(self):
        """
        Initialize StatsMixin
        """
        self._init_time = time.time()
        self._num_providers = 0

    def increment_provider_count(self):
        """
        Increment the number of providers
        """
        self._num_providers += 1

    def decrement_provider_count(self):
        """
        Decrement the number of providers
        """
        self._num_providers -= 1

    def get(self):
        """
        Get the stats information

        :rtype: :class:`tuple(:class:`time`, :class:`long`)`
        :return: Return the init time and list of providers
        """
        return (self._init_time, self._num_providers)
