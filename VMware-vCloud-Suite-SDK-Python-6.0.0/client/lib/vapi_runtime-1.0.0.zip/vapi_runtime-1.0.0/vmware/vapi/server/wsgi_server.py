"""
Wsgi Server
"""

__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2014 VMware, Inc.  All rights reserved. -- VMware Confidential'

import logging

from vmware.vapi.server.server_interface import ServerInterface


logger = logging.getLogger(__name__)


class WsgiApplication(object):
    """
    Python WSGI application. For more details about WSGI
    specification, see PEP 333.
    """
    def __init__(self, msg_handler_map):
        """
        Initialize WsgiApplication

        :type  msg_handler_map: :class:`dict` of :class:`str` and
            :class:`vmware.vapi.protocol.server.api_handler.ApiHandler`
        :param msg_handler_map: Map of content type to the message
            handler for that content type
        """
        self._msg_handler_map = msg_handler_map

    def __call__(self, environ, start_response):
        """
        The implementation of WsgiApplication

        :type  environ: :class:`dict`
        :param environ: Dictionary object containing CGI-style environment
            variables.
        :type  start_response: :class:`func`
        :param start_response: Callable accepting status code, response headers
            and exc_info.
        """
        content_type = environ.get('CONTENT_TYPE')
        handler = self._msg_handler_map.get(content_type)
        if handler is None:
            status = '400 Bad Request'
            result = ''
        else:
            try:
                status = '200 OK'
                # NYI: Check content length
                result = handler.handle_request(environ['wsgi.input'])
            except Exception as e:
                logger.exception(e)
                status = '500 Internal Server Error'
                result = ''
        start_response(status, [('CONTENT_TYPE', content_type)])
        return result


class WsgiServer(ServerInterface):
    """
    Server wrapper class for Wsgi application.
    """

    SUPPORTED_SCHEMES = ('http', 'https')
    HTTP_CONTENT_MAPPING = {'json': 'application/json',
                            'xml': 'text/xml',
                            '': ''}

    def __init__(self):
        """
        Initialize WsgiServer
        """
        self._protocol_handler_map = {}
        ServerInterface.__init__(self)

    def register_handler(self, addr, msg_type, protocol_handler, ssl_args=None):
        """
        Register protocol handler

        :type  addr: :class:`str`
        :param addr: addr url
        :type  msg_type: :class:`str`
        :param msg_type: protocol message type
        :type  protocol_handler: :class:`vmware.vapi.protocol.server.transport.async_protocol_handler.AsyncProtocolHandler`
        :param protocol_handler: protocol handler for this addr
        :type  ssl_args: :class:`dict`
        :param ssl_args: ssl arguments
        """
        assert(protocol_handler)
        content_type = self.HTTP_CONTENT_MAPPING.get(msg_type)
        if content_type is None:
            logger.error('Unsupported msg type: %s', msg_type)
            return
        self._protocol_handler_map[content_type] = protocol_handler

    def get_wsgi_application(self):
        """
        Returns the WSGI application.

        :rtype: :class:`vmware.vapi.server.wsgi_server.WsgiApplication`
        :return: WSGI application.
        """
        return WsgiApplication(self._protocol_handler_map)

    def serve_forever(self):
        pass

    def shutdown(self):
        pass


def get_server(cfg):  # pylint: disable=W0613
    """
    Get wsgi server

    :type  cfg: :class:`ConfigParser.SafeConfigParser`
    :param cfg: Config parser
    :rtype: :class:`vmware.vapi.server.server_interface.ServerInterface`
    :return: subclass of ServerInterface
    """
    return WsgiServer()
