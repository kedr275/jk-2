"""
Convenient libraries for DynamicValue
"""

__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2013-2014 VMware, Inc.  All rights reserved. -- VMware Confidential'

from datetime import datetime
import decimal
import six

from vmware.vapi.data.value import (
    SimpleValueVisitor, VoidValue, BooleanValue, IntegerValue, DoubleValue,
    StringValue, BlobValue, SecretValue, OptionalValue, ListValue)
from vmware.vapi.bindings.struct import VapiStruct
from vmware.vapi.bindings.error import VapiError
from vmware.vapi.bindings.enum import Enum
from vmware.vapi.bindings.datetime_helper import DateTimeConverter
from vmware.vapi.lib.constants import MAP_ENTRY

# pylint: disable=E1102


class DataValueToDynamicValueVisitor(SimpleValueVisitor):
    """
    Visitor to convert DataValue to DynamicValue
    """
    def __init__(self, dynamic_value_class, optional_dynamic_value_class):
        """
        Initialize DataValueToDynamicValueVisitor

        :type  dynamic_value_class: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value_class: DynamicValue class reference
        :type  optional_dynamic_value_class:
            :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param optional_dynamic_value_class: OptionalDynamicValue class reference
        """
        self._dynamic_value_class = dynamic_value_class
        self._optional_dynamic_value_class = optional_dynamic_value_class
        self._out_value = None
        SimpleValueVisitor.__init__(self)

    def get_out_value(self):
        """
        Returns the output value

        :rtype: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :return: DynamicValue generated from DataValue
        """
        return self._out_value

    def visit_void(self, value):
        self._out_value = self._dynamic_value_class(
            type=self._dynamic_value_class.Type.VOID)

    def visit_integer(self, value):
        self._out_value = self._dynamic_value_class(
            type=self._dynamic_value_class.Type.LONG,
            long_value=value.value)

    def visit_double(self, value):
        self._out_value = self._dynamic_value_class(
            type=self._dynamic_value_class.Type.DOUBLE,
            double_value=value.value)

    def visit_string(self, value):
        self._out_value = self._dynamic_value_class(
            type=self._dynamic_value_class.Type.STRING,
            string_value=value.value)

    def visit_boolean(self, value):
        self._out_value = self._dynamic_value_class(
            type=self._dynamic_value_class.Type.BOOLEAN,
            boolean_value=value.value)

    def visit_blob(self, value):
        self._out_value = self._dynamic_value_class(
            type=self._dynamic_value_class.Type.BINARY,
            binary_value=value.value)

    def visit_secret(self, value):
        self._out_value = self._dynamic_value_class(
            type=self._dynamic_value_class.Type.SECRET,
            secret_value=value.value)

    def visit_struct(self, value):
        self._out_value = self._dynamic_value_class(
            type=self._dynamic_value_class.Type.STRUCTURE,
            structure_value=VapiStruct(struct_value=value))

    def visit_error(self, value):
        self._out_value = self._dynamic_value_class(
            type=self._dynamic_value_class.Type.ERROR,
            error_value=VapiError({}, value))

    def visit_optional(self, value):
        element_value = self._optional_dynamic_value_class()
        if value.is_set():
            value.value.accept(self)
            element_value = self._optional_dynamic_value_class(
                optional_value=self.get_out_value())
        else:
            element_value = self._optional_dynamic_value_class()
        out_value = self._dynamic_value_class(
            type=self._dynamic_value_class.Type.OPTIONAL,
            optional_value=element_value)
        self._out_value = out_value

    def visit_list(self, value):
        out_value = self._dynamic_value_class(
            type=self._dynamic_value_class.Type.LIST,
            list_value=[])
        for element in value:
            element.accept(self)
            out_value.list_value.append(self.get_out_value())
        self._out_value = out_value


class DynamicValueToDataValueVisitor(object):
    """
    Visitor to convert DynamicValue to DataValue
    """
    def __init__(self, dynamic_value_class):
        """
        Initialize DynamicValueToDataValueVisitor

        :type  dynamic_value_class: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value_class: DynamicValue class reference
        """
        self._out_value = None
        self._dynamic_value_class = dynamic_value_class
        self._dispatch_map = {
            dynamic_value_class.Type.VOID: self.visit_void,
            dynamic_value_class.Type.BOOLEAN: self.visit_boolean,
            dynamic_value_class.Type.DOUBLE: self.visit_double,
            dynamic_value_class.Type.LONG: self.visit_long,
            dynamic_value_class.Type.STRING: self.visit_string,
            dynamic_value_class.Type.BINARY: self.visit_binary,
            dynamic_value_class.Type.SECRET: self.visit_secret,
            dynamic_value_class.Type.STRUCTURE: self.visit_structure,
            dynamic_value_class.Type.ERROR: self.visit_error,
            dynamic_value_class.Type.OPTIONAL: self.visit_optional,
            dynamic_value_class.Type.LIST: self.visit_list,
        }

    def get_out_value(self):
        """
        Returns the DataValue

        :rtype: :class:`vmware.vapi.data.value.DataValue`
        :return: DataValue generated from DynamicValue
        """
        return self._out_value

    def visit(self, dynamic_value):
        """
        Visit a DynamicValue

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        visit_method = self._dispatch_map.get(dynamic_value.type)
        visit_method(dynamic_value)

    def visit_void(self, dynamic_value):  # pylint: disable=W0613
        """
        Visit a DynamicValue whose type is VOID

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        self._out_value = VoidValue()

    def visit_boolean(self, dynamic_value):
        """
        Visit a DynamicValue whose type is BOOLEAN

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        self._out_value = BooleanValue(dynamic_value.boolean_value)

    def visit_double(self, dynamic_value):
        """
        Visit a DynamicValue whose type is DOUBLE

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        self._out_value = DoubleValue(dynamic_value.double_value)

    def visit_long(self, dynamic_value):
        """
        Visit a DynamicValue whose type is LONG

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        self._out_value = IntegerValue(dynamic_value.long_value)

    def visit_string(self, dynamic_value):
        """
        Visit a DynamicValue whose type is STRING

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        self._out_value = StringValue(dynamic_value.string_value)

    def visit_binary(self, dynamic_value):
        """
        Visit a DynamicValue whose type is BINARY

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        self._out_value = BlobValue(dynamic_value.binary_value)

    def visit_secret(self, dynamic_value):
        """
        Visit a DynamicValue whose type is SECRET

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        self._out_value = SecretValue(dynamic_value.secret_value)

    def visit_structure(self, dynamic_value):
        """
        Visit a DynamicValue whose type is STRUCTURE

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        self._out_value = dynamic_value.structure_value.get_struct_value()

    def visit_error(self, dynamic_value):
        """
        Visit a DynamicValue whose type is ERROR

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        self._out_value = dynamic_value.error_value.get_error_value()

    def visit_optional(self, dynamic_value):
        """
        Visit a DynamicValue whose type is OPTIONAL

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        element_value = None
        if dynamic_value.optional_value.optional_value is not None:
            self.visit(dynamic_value.optional_value.optional_value)
            element_value = self.get_out_value()
        self._out_value = OptionalValue(element_value)

    def visit_list(self, dynamic_value):
        """
        Visit a DynamicValue whose type is LIST

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        elements = []
        for val in dynamic_value.list_value:
            self.visit(val)
            elements.append(self.get_out_value())
        self._out_value = ListValue(elements)


class BaseDataValueConverter(object):
    """
    Class to convert DataValue <-> DynamicValue

    Note: This is an internal helper class for supporting this
    functionality in client and provider standard libraries. This
    class should be derived and the derived class should initialize
    dynamic_value_class and optional_dynamic_value_class with the
    appropriate class references.

    :type dynamic_value_class: :class:`vmware.vapi.bindings.struct.VapiStruct`
    :cvar dynamic_value_class: Dynamic value class reference
    :type optional_dynamic_value_class: :class:`vmware.vapi.bindings.struct.VapiStruct`
    :cvar optional_dynamic_value_class: Optional dynamic value class reference
    """
    dynamic_value_class = None
    optional_dynamic_value_class = None

    @classmethod
    def to_dynamic_value(cls, data_value):
        """
        Convert a given DataValue to DynamicValue

        :type  data_value: :class:`vmware.vapi.data.value.DataValue`
        :param data_value: DataValue to be converted
        :rtype: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :return: DynamicValue generated from DataValue
        """
        visitor = DataValueToDynamicValueVisitor(
            cls.dynamic_value_class, cls.optional_dynamic_value_class)
        data_value.accept(visitor)
        return visitor.get_out_value()

    @classmethod
    def to_data_value(cls, dynamic_value):
        """
        Convert a given DynamicValue to DataValue

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be converted
        :rtype: :class:`vmware.vapi.data.value.DataValue`
        :return: DataValue generated from DynamicValue
        """
        visitor = DynamicValueToDataValueVisitor(cls.dynamic_value_class)
        visitor.visit(dynamic_value)
        return visitor.get_out_value()


class NativeValueToDynamicValueVisitor(object):
    """
    Visitor to convert Native value to Dynamic value
    """
    def __init__(self, dynamic_value_class, optional_dynamic_value_class,
                 is_optional=False, is_secret=False, is_binary=False):
        """
        Initialize DynamicValueToDataValueVisitor

        :type  dynamic_value_class: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value_class: DynamicValue class reference
        :type  optional_dynamic_value_class:
            :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param optional_dynamic_value_class: OptionalDynamicValue class reference
        :type  is_optional: :class:`bool`
        :param is_optional: If true, after conversion of native
            value to dynamic value, the output is wrapped in an
            dynamic value whose type is OPTIONAL.
        :type  is_secret: :class:`bool`
        :param is_secret: If true, and the native value is a string, the type of
            the dynamic value returned will be secret. This boolean option, is
            also passed to the elements of generic types such as List and
            Set.
        :type  is_binary: :class:`bool`
        :param is_binary: If true, and the native value is a string, the type of
            the dynamic value returned will be binary. This boolean option, is
            also passed to the elements of generic types such as List and
            Set.
        """
        self._out_value = None
        self._dynamic_value_class = dynamic_value_class
        self._optional_dynamic_value_class = optional_dynamic_value_class
        self._is_optional = is_optional
        self._is_secret = is_secret
        self._is_binary = is_binary
        self._dispatch_map = {
            type(None): self.visit_void,
            datetime: self.visit_datetime,
            float: self.visit_double,
            decimal.Decimal: self.visit_double,
            bool: self.visit_boolean,
            list: self.visit_list,
            set: self.visit_list,
        }

    def get_out_value(self):
        """
        Returns the DataValue

        :rtype: :class:`vmware.vapi.data.value.DataValue`
        :return: DataValue generated from DynamicValue
        """
        if self._is_optional:
            optional_dynamic_value = None
            if self._out_value.type == self._dynamic_value_class.Type.VOID:
                optional_dynamic_value = self._optional_dynamic_value_class()
            else:
                optional_dynamic_value = self._optional_dynamic_value_class(
                    optional_value=self._out_value)
            self._out_value = self._dynamic_value_class(
                type=self._dynamic_value_class.Type.OPTIONAL,
                optional_value=optional_dynamic_value)
        return self._out_value

    def visit(self, native_value):
        """
        Visit a native value

        :type  native_value: :class:`object`
        :param native_value: Native value to be converted
        """
        native_type = type(native_value)
        visit_method = self._dispatch_map.get(native_type)
        if not visit_method:
            # Handle the string and integer types explicitly
            # as they are different in Py2 and Py3
            if isinstance(native_value, six.string_types):
                visit_method = self.visit_string
            elif isinstance(native_value, six.integer_types):
                visit_method = self.visit_long
            # Handle user defined types
            elif isinstance(native_value, VapiError):
                visit_method = self.visit_error
            elif isinstance(native_value, VapiStruct):
                visit_method = self.visit_structure
            elif isinstance(native_value, Enum):
                visit_method = self.visit_enumeration
        visit_method(native_value)

    def visit_void(self, native_value):
        """
        visit a native value whose value is None type

        :type  native_value: :class:`None`
        :param native_value: Native value to be converted
        """
        self._out_value = self._dynamic_value_class(
            type=self._dynamic_value_class.Type.VOID)

    def visit_string(self, native_value):
        """
        visit a native value whose value is string type

        :type  native_value: :class:`str`
        :param native_value: Native value to be converted
        """
        if self._is_binary:
            self._out_value = self._dynamic_value_class(
                type=self._dynamic_value_class.Type.BINARY,
                binary_value=native_value)
        elif self._is_secret:
            self._out_value = self._dynamic_value_class(
                type=self._dynamic_value_class.Type.SECRET,
                secret_value=native_value)
        else:
            self._out_value = self._dynamic_value_class(
                type=self._dynamic_value_class.Type.STRING,
                string_value=native_value)

    def visit_datetime(self, native_value):
        """
        visit a native value whose value is datetime type

        :type  native_value: :class:`datetime.datetime`
        :param native_value: Native value to be converted
        """
        string_value = DateTimeConverter.convert_from_datetime(native_value)
        self._out_value = self._dynamic_value_class(
            type=self._dynamic_value_class.Type.STRING,
            string_value=string_value)

    def visit_double(self, native_value):
        """
        visit a native value whose value is double type

        :type  native_value: :class:`double` or :class:`decimal.Decimal`
        :param native_value: Native value to be converted
        """
        self._out_value = self._dynamic_value_class(
            type=self._dynamic_value_class.Type.DOUBLE,
            double_value=native_value)

    def visit_boolean(self, native_value):
        """
        visit a native value whose value is bool type

        :type  native_value: :class:`bool`
        :param native_value: Native value to be converted
        """
        self._out_value = self._dynamic_value_class(
            type=self._dynamic_value_class.Type.BOOLEAN,
            boolean_value=native_value)

    def visit_long(self, native_value):
        """
        visit a native value whose value is long type

        :type  native_value: :class:`int` or :class:`long`
        :param native_value: Native value to be converted
        """
        self._out_value = self._dynamic_value_class(
            type=self._dynamic_value_class.Type.LONG,
            long_value=native_value)

    def visit_list(self, native_value):
        """
        visit a native value whose value is list or set type

        :type  native_value: :class:`list` or :class:`set`
        :param native_value: Native value to be converted
        """
        elements = []
        for value in native_value:
            self.visit(value)
            elements.append(self.get_out_value())
        self._out_value = self._dynamic_value_class(
            type=self._dynamic_value_class.Type.LIST,
            list_value=elements)

    def visit_structure(self, native_value):
        """
        visit a native value whose value is vAPI structure type

        :type  native_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param native_value: Native value to be converted
        """
        self._out_value = self._dynamic_value_class(
            type=self._dynamic_value_class.Type.STRUCTURE,
            structure_value=VapiStruct(
                struct_value=native_value.get_struct_value()))

    def visit_error(self, native_value):
        """
        visit a native value whose value is vAPI error type

        :type  native_value: :class:`vmware.vapi.bindings.error.VapiError`
        :param native_value: Native value to be converted
        """
        self._out_value = self._dynamic_value_class(
            type=self._dynamic_value_class.Type.ERROR,
            error_value=VapiError(
                error_value=native_value.get_error_value()))

    def visit_enumeration(self, native_value):
        """
        visit a native value whose value is vAPI enumeration type

        :type  native_value: :class:`vmware.vapi.bindings.enum.Enum`
        :param native_value: Native value to be converted
        """
        self._out_value = self._dynamic_value_class(
            type=self._dynamic_value_class.Type.STRING,
            string_value=str(native_value))


class DynamicValueToNativeValueVisitor(object):
    """
    Visitor to convert DynamicValue to python native value
    """
    def __init__(self, dynamic_value_class, optional_dynamic_value_class,
                 is_set=False, is_datetime=False,
                 user_defined_class_reference=None):
        """
        Initialize DynamicValueToDataValueVisitor

        :type  dynamic_value_class: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value_class: DynamicValue class reference
        :type  optional_dynamic_value_class:
            :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param optional_dynamic_value_class: OptionalDynamicValue class reference
        :type  is_set: :class:`bool`
        :param is_set: If true, and the dynamic value is a list, the type of
            the native value returned will be a set. This boolean option, is
            also passed to the elements of generic types such as List and
            Optional. If the dynamic value represents a Map, this option is
            used only for the conversion of values of the Map.
        :type  is_datetime: :class:`bool`
        :param is_datetime: If true, and the dynamic value is a string, the type of
            the native value returned will be a datetime. This boolean option, is
            also passed to the elements of generic types such as List and
            Optional. If the dynamic value represents a Map, this option is
            used only for the conversion of values of the Map.
        :type  user_defined_class_reference:
            :class:`vmware.vapi.bindings.struct.VapiStruct` or
            :class:`vmware.vapi.bindings.error.VapiError` or
            :class:`vmware.vapi.bindings.enum.Enum`
        :param user_defined_class_reference: This class reference is used to
            create native instances of user defined types (structures, errors
            and enumerations). If the dynamic value is a Structure, instead of
            returning VapiStruct, an instance of this class is returned. If the
            dynamic value is an Error, instead of returning VapiError, an instance
            of this class is returned. If the dynamic value is String, instead of
            returning a string, an instance of this class is returned.
        """
        self._out_value = None
        self._dynamic_value_class = dynamic_value_class
        self._optional_dynamic_value_class = optional_dynamic_value_class
        self._is_set = is_set
        self._is_datetime = is_datetime
        self._user_defined_class_reference = user_defined_class_reference
        self._dispatch_map = {
            dynamic_value_class.Type.VOID: self.visit_void,
            dynamic_value_class.Type.BOOLEAN: self.visit_boolean,
            dynamic_value_class.Type.DOUBLE: self.visit_double,
            dynamic_value_class.Type.LONG: self.visit_long,
            dynamic_value_class.Type.STRING: self.visit_string,
            dynamic_value_class.Type.BINARY: self.visit_binary,
            dynamic_value_class.Type.SECRET: self.visit_secret,
            dynamic_value_class.Type.STRUCTURE: self.visit_structure,
            dynamic_value_class.Type.ERROR: self.visit_error,
            dynamic_value_class.Type.OPTIONAL: self.visit_optional,
            dynamic_value_class.Type.LIST: self.visit_list,
        }

    def get_out_value(self):
        """
        Returns the DataValue

        :rtype: :class:`vmware.vapi.data.value.DataValue`
        :return: DataValue generated from DynamicValue
        """
        return self._out_value

    def visit(self, dynamic_value):
        """
        Visit a DynamicValue

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        visit_method = self._dispatch_map.get(dynamic_value.type)
        visit_method(dynamic_value)

    def visit_void(self, dynamic_value):  # pylint: disable=W0613
        """
        Visit a DynamicValue whose type is VOID

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        self._out_value = None

    def visit_boolean(self, dynamic_value):
        """
        Visit a DynamicValue whose type is BOOLEAN

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        self._out_value = dynamic_value.boolean_value

    def visit_double(self, dynamic_value):
        """
        Visit a DynamicValue whose type is DOUBLE

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        self._out_value = dynamic_value.double_value

    def visit_long(self, dynamic_value):
        """
        Visit a DynamicValue whose type is LONG

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        self._out_value = dynamic_value.long_value

    def visit_string(self, dynamic_value):
        """
        Visit a DynamicValue whose type is STRING

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        self._out_value = dynamic_value.string_value
        if self._is_datetime:
            self._out_value = DateTimeConverter.convert_to_datetime(
                self._out_value)
        elif self._user_defined_class_reference is not None:
            # Create enumeration type instance
            self._out_value = self._user_defined_class_reference(
                self._out_value)

    def visit_binary(self, dynamic_value):
        """
        Visit a DynamicValue whose type is BINARY

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        self._out_value = dynamic_value.binary_value

    def visit_secret(self, dynamic_value):
        """
        Visit a DynamicValue whose type is SECRET

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        self._out_value = dynamic_value.secret_value

    def visit_structure(self, dynamic_value):
        """
        Visit a DynamicValue whose type is STRUCTURE

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        out_value = dynamic_value.structure_value
        struct_value = out_value.get_struct_value()
        if struct_value.name == MAP_ENTRY:
            key = struct_value.get_field('key').value
            map_value_as_data_value = struct_value.get_field('value')
            BaseDataValueConverter.dynamic_value_class = self._dynamic_value_class
            BaseDataValueConverter.optional_dynamic_value_class = self._optional_dynamic_value_class
            map_value_as_dynamic_value = BaseDataValueConverter.to_dynamic_value(
                map_value_as_data_value)
            self.visit(map_value_as_dynamic_value)
            value = self.get_out_value()
            out_value = {key: value}
        elif self._user_defined_class_reference is not None:
            out_value = out_value.convert_to(self._user_defined_class_reference)
        self._out_value = out_value

    def visit_error(self, dynamic_value):
        """
        Visit a DynamicValue whose type is ERROR

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        self._out_value = dynamic_value.error_value
        if self._user_defined_class_reference is not None:
            self._out_value = self._out_value.convert_to(
                self._user_defined_class_reference)

    def visit_optional(self, dynamic_value):
        """
        Visit a DynamicValue whose type is OPTIONAL

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        optional_value = dynamic_value.optional_value.optional_value
        if optional_value is not None:
            self.visit(optional_value)
            self._out_value = self.get_out_value()

    def visit_list(self, dynamic_value):
        """
        Visit a DynamicValue whose type is LIST

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be visited
        """
        out_value = []
        for value in dynamic_value.list_value:
            self.visit(value)
            out_value.append(self.get_out_value())
        if out_value and isinstance(out_value[0], dict):
            map_value = {}
            # Its a map
            for dict_item in out_value:
                map_value.update(dict_item)
            out_value = map_value
        elif self._is_set:
            out_value = set(out_value)
        self._out_value = out_value


class BaseNativeValueConverter(object):
    """
    class to convert Native value <-> DynamicValue.

    Note: This is an internal helper class for supporting this
    functionality in client and provider standard libraries. This
    class should be derived and the derived class should initialize
    dynamic_value_class and optional_dynamic_value_class with the
    appropriate class references.

    :type dynamic_value_class: :class:`vmware.vapi.bindings.struct.VapiStruct`
    :cvar dynamic_value_class: Dynamic value class reference
    :type optional_dynamic_value_class: :class:`vmware.vapi.bindings.struct.VapiStruct`
    :cvar optional_dynamic_value_class: Optional dynamic value class reference
    """
    dynamic_value_class = None
    optional_dynamic_value_class = None

    @classmethod
    def to_dynamic_value(cls, native_value, is_optional=False,
                         is_secret=False, is_binary=False):
        """
        Convert a given native value to DynamicValue

        :type  native_value: :class:`object`
        :param native_value: Native value to be converted
        :type  is_optional: :class:`bool`
        :param is_optional: If true, after conversion of native
            value to dynamic value, the output is wrapped in an
            dynamic value whose type is OPTIONAL.
        :type  is_secret: :class:`bool`
        :param is_secret: If true, and the native value is a string, the type of
            the dynamic value returned will be secret. This boolean option, is
            also passed to the elements of generic types such as List and
            Set.
        :type  is_binary: :class:`bool`
        :param is_binary: If true, and the native value is a string, the type of
            the dynamic value returned will be binary. This boolean option, is
            also passed to the elements of generic types such as List and
            Set.
        :rtype: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :return: DynamicValue generated from DataValue
        """
        visitor = NativeValueToDynamicValueVisitor(
            cls.dynamic_value_class, cls.optional_dynamic_value_class,
            is_optional, is_secret, is_binary)
        visitor.visit(native_value)
        return visitor.get_out_value()

    @classmethod
    def to_native_value(cls, dynamic_value, is_set=False, is_datetime=False,
                        user_defined_class_reference=None):
        """
        Convert a given DynamicValue to native value

        :type  dynamic_value: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param dynamic_value: DynamicValue to be converted
        :type  is_set: :class:`bool`
        :param is_set: If true, and the dynamic value is a list, the type of
            the native value returned will be a set. This boolean option, is
            also passed to the elements of generic types such as List and
            Optional. If the dynamic value represents a Map, this option is
            used only for the conversion of values of the Map.
        :type  is_datetime: :class:`bool`
        :param is_datetime: If true, and the dynamic value is a string, the type of
            the native value returned will be a datetime. This boolean option, is
            also passed to the elements of generic types such as List and
            Optional. If the dynamic value represents a Map, this option is
            used only for the conversion of values of the Map.
        :type  user_defined_class_reference:
            :class:`vmware.vapi.bindings.struct.VapiStruct` or
            :class:`vmware.vapi.bindings.error.VapiError` or
            :class:`vmware.vapi.bindings.enum.Enum`
        :param user_defined_class_reference: This class reference is used to
            create native instances of user defined types (structures, errors
            and enumerations). If the dynamic value is a Structure, instead of
            returning VapiStruct, an instance of this class is returned. If the
            dynamic value is an Error, instead of returning VapiError, an instance
            of this class is returned. If the dynamic value is String, instead of
            returning a string, an instance of this class is returned.
        :rtype: :class:`object`
        :return: Native value generated
        """
        visitor = DynamicValueToNativeValueVisitor(
            cls.dynamic_value_class, cls.optional_dynamic_value_class,
            is_set, is_datetime, user_defined_class_reference)
        visitor.visit(dynamic_value)
        return visitor.get_out_value()
