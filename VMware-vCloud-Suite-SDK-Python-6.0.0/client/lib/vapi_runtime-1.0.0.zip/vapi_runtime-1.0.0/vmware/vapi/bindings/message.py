"""
Message Factory import for the bindings to use
"""
__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2012 VMware, Inc.  All rights reserved. -- VMware Confidential'

from vmware.vapi.message import MessageFactory  # pylint: disable=W0611
