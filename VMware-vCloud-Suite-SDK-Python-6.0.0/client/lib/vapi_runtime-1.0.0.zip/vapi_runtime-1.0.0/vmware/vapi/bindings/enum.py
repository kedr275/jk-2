"""
Bindings data classes
"""

__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2012 VMware, Inc.  All rights reserved. -- VMware Confidential'


# Disabling the pylint complaint about badly implemented container
# as we don't need __setitem__, __delitem__ and __getitem__
class Enum(str):  # pylint: disable=R0924
    """
    Representation of IDL Enum in python language bindings
    """
    _binding_type = None

    @classmethod
    def _set_binding_type(cls, binding_type):
        """
        Set the underlying BindingType for this VapiStruct.

        :type  binding_type: :class:`vmware.vapi.data.value.BindingType`
        :param binding_type: BindingType for this VapiStruct
        """
        cls._binding_type = binding_type

    @classmethod
    def get_binding_type(cls):
        """
        Returns the corresponding BindingType for the VapiStruct class

        :rtype: :class:`vmware.vapi.data.value.BindingType`
        :return: BindingType for this VapiStruct
        """
        return getattr(cls, '_binding_type', None)

    def __repr__(self):
        class_name = self.__class__.__name__
        return '%s(string=%s)' % (class_name, str.__repr__(self))
