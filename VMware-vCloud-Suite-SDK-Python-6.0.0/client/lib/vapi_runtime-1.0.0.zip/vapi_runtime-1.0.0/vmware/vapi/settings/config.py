"""
Configuration management for vAPI providers
"""

__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2012 VMware, Inc.  All rights reserved. -- VMware Confidential'


# Singleton config variable
cfg = None
