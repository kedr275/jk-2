#!/usr/bin/env python

"""
Section names used in vAPI properties file
"""

__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2011 VMware, Inc.  All rights reserved. -- VMware Confidential'

ENDPOINT = 'endpoint'
SSL = 'ssl'
LOGGERS = 'loggers'
