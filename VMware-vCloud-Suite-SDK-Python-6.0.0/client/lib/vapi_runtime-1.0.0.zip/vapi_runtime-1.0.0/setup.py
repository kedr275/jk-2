"""
Setup file for creating Runtime package
"""
__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2012-2014 VMware, Inc.  All rights reserved. -- VMware Confidential'

try:
    from setuptools import setup, find_packages
except ImportError:
    from distribute_setup import use_setuptools
    use_setuptools()
    from setuptools import setup, find_packages
from vmware.vapi import __version__

setup(
    name='vapi_runtime',
    version=__version__,
    description='vAPI Runtime',
    classifiers=[],
    keywords='VMware',
    author='VMware',
    namespace_packages=['vmware'],
    packages=find_packages(),
    package_data={
        'vmware': ['vapi/settings/*.properties'],
    },
    include_package_data=True,
    zip_safe=False,
    install_requires=['setuptools',
                      'simplejson>=2.6.2',
                      'pyOpenSSL==0.14',
                      'requests==2.4.0',
                      'six==1.7.3'],
    entry_points={
        'console_scripts': [
            'vapi-server = vmware.vapi.server.vapid:main'
        ]
    }
)
