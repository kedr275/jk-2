"""
Setup file for vAPI Common Client package
"""
__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2012-2014 VMware, Inc.  All rights reserved. -- VMware Confidential'

from vmware.vapi.stdlib.client import __version__

from setuptools import setup, find_packages
setup(
    name='vapi_common_client',
    version=__version__,
    namespace_packages=['com', 'vmware'],
    packages=find_packages(),
    description='vAPI Common Services Client Bindings',
    install_requires=['vapi-runtime==1.0.0'],
    author='VMware',
)
